
public class Deli {
	
	MinHeap<Customer> heap;
	
	public Deli() {
		if(heap == null) {
			heap = new MinHeap<Customer>();
		}
	}
	public void addCustomer(Customer cust0){
		heap.addElement(cust0);
	}
	
	public void processCustomers() {
		heap.removeMin();
		heap.toString();
	}
	 
}
