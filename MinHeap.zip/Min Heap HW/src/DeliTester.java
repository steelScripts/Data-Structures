public class DeliTester {
	public static void main(String[] args){
		Deli deli = new Deli();
		Customer cust0 = new Customer("Maggie", "Simpson", 101);
		Customer cust1 = new Customer("Bart", "Simpson", 103);
		Customer cust2 = new Customer("Lisa", "Simpson", 104);
		Customer cust3 = new Customer("Marge", "Simpson", 112);
		Customer cust4 = new Customer("Homer", "Simpson", 120);
		
		deli.addCustomer(cust0);
		deli.addCustomer(cust1);
		deli.addCustomer(cust2);
		deli.addCustomer(cust3);
		deli.addCustomer(cust4);
		
		deli.processCustomers();
	}
		
}
