
public class Customer implements Comparable {
	public String firstName, lastName;
	public int ticket;
	
	public Customer(String first, String last, int ticket){
		if(this.firstName == null){
			this.firstName = first;
		}
		if(this.lastName == null){
			this.lastName = last;
		}
		this.ticket = ticket;
		
	}
	
	@Override
	public int compareTo(Object args0) {
		int result;
		if(this.ticket > ((Customer) args0).getTicket())
			result = -1;
		else if(this.ticket == ((Customer) args0).getTicket())
			result = 0;
		else 
			result = 1;
		return result;
	}
	
	public int getTicket(){
		return this.ticket;
	}
	
	public String getFirstName(){
		return firstName;
	}
	
	public String getLastName(){
		return lastName;
	}
	
	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("First Name: " + this.getFirstName());
		buf.append("\n");
		buf.append("Last Name: " + this.getLastName());
		buf.append("\n");
		buf.append("Ticket: " + this.getTicket());
		return buf.toString();
	}
}