import java.lang.String;
import java.lang.StringBuffer;
public class Car {
	private String plateNumber,
				   make,
				   model,
				   color,
				   year,
				   price;
	/*********GETTERS************/
	public String getPlateNumber() {
		return this.plateNumber;
	}
	
	public String getMake() {
		return this.make;
	}
	public String getModel() {
		return this.model;
	}
	public String getColor() {
		return this.color;
	}
	public String getYear() {
		return this.year;
	}
	public String getPrice() {
		return this.price;
	}
	
	/*********Constructor**********/
	public Car(String plate, String make, String model, String color, String year, String price){
		this.plateNumber = plate;
		this.make = make;
		this.model = model;
		this.color = color;
		this.year = year;
		this.price = price; 
	}
	
	/*********To String***********/
	public String toString(){
		StringBuffer buf = new StringBuffer();
		
		buf.append("Plate Number: ");
		buf.append(this.plateNumber);
		buf.append("\n");
		
		buf.append("Make: ");
		buf.append(this.make);
		buf.append("\n");
		
		buf.append("Model: ");
		buf.append(this.model);
		buf.append("\n");
		
		buf.append("Color: ");
		buf.append(this.color);
		buf.append("\n");
		
		buf.append("Year: ");
		buf.append(this.year);
		buf.append("\n");
		
		buf.append("Price: ");
		buf.append(this.price);
		buf.append("\n");
		
		return buf.toString();
	}
}
