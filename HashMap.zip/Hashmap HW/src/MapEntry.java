
public class MapEntry<K, V> {
	public K key = null;
	public V value = null;
	
	/******Constructor*******/
	public MapEntry(K key, V value){
		this.key = key;
		this.value = value;
	}
}
