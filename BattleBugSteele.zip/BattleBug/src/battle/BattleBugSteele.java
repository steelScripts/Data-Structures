package battle;
import info.gridworld.grid.Location;
import info.gridworld.grid.BoundedGrid;
import java.util.ArrayList;


/**
 * This BattleBug moves towards open space.
 * 
 * @author Andrew Steele
 *
 */
public class BattleBugSteele extends AbstractBattleBug {
	
	/**
	 * Sends the battlebug to the direction with the most open space by counting
	 * the spaces until a collision in each direction and going for the one with
	 * the highest number spaces.
	 * @return
	 */
	protected int openDirection() {
		int direction = 0; //int representing a direction
		int mostOpen = 0; //int representing most open direction
		int[] spacesOpen = null; //holds amount of open spaces for each direction clockwise
		int freeSpaces = 0; //placeholder value for free spaces of single direction
		int totalRows = getGrid().getNumRows();
		int totalCols = getGrid().getNumCols();
		Location locChecker = getLocation();
		int allChecked = 0;
		
		while(allChecked < 360) {
			switch (direction) {
				case 0:		locChecker = new Location(getLocation().getRow() - 1, getLocation().getCol());
							while(getGrid().isValid(locChecker)) {
								locChecker = new Location(getLocation().getRow() - 1, getLocation().getCol());
								freeSpaces++;
							}
							spacesOpen[0] = freeSpaces;
							freeSpaces = 0;
							direction += 45;
							break;
							
				case 45:	locChecker = new Location(getLocation().getRow() - 1, getLocation().getCol() + 1);
							while(getGrid().isValid(locChecker)) {
								locChecker = new Location(getLocation().getRow() - 1, getLocation().getCol() - 1);
								freeSpaces++;
							}
							spacesOpen[1] = freeSpaces;
							freeSpaces = 0;
							direction += 45;
							break;
							
				case 90:	locChecker = new Location(getLocation().getRow(), getLocation().getCol() + 1);
							while(getGrid().isValid(locChecker)) {
								locChecker = new Location(getLocation().getRow(), getLocation().getCol() + 1);
								freeSpaces++;
							}
							spacesOpen[2] = freeSpaces;
							freeSpaces = 0;
							direction += 45;
							break;
							
				case 135: 	locChecker = new Location(getLocation().getRow() + 1, getLocation().getCol() + 1);
							while(getGrid().isValid(locChecker)) {
								locChecker = new Location(getLocation().getRow() + 1, getLocation().getCol() + 1);
								freeSpaces++;
							}
							spacesOpen[3] = freeSpaces;
							freeSpaces = 0;
							direction += 45;
							break;
				case 180:	locChecker = new Location(getLocation().getRow() + 1, getLocation().getCol());
							while(getGrid().isValid(locChecker)) {
								locChecker = new Location(getLocation().getRow() + 1, getLocation().getCol());
								freeSpaces++;
							}
							spacesOpen[4] = freeSpaces;
							freeSpaces = 0;
							direction += 45;
							break;
							
				case 225:	locChecker = new Location(getLocation().getRow() + 1, getLocation().getCol() - 1);
							while(getGrid().isValid(locChecker)) {
								locChecker = new Location(getLocation().getRow() + 1, getLocation().getCol() - 1);
								freeSpaces++;
							}
							spacesOpen[5] = freeSpaces;
							freeSpaces = 0;
							direction += 45;
							break; 
							
				case 270:	locChecker = new Location(getLocation().getRow(), getLocation().getCol() - 1);
							while(getGrid().isValid(locChecker)) {
								locChecker = new Location(getLocation().getRow() + 1, getLocation().getCol() - 1);
								freeSpaces++;
							}
							spacesOpen[6] = freeSpaces;
							freeSpaces = 0;
							direction += 45;
							break;
							
				case 315:	locChecker = new Location(getLocation().getRow() - 1, getLocation().getCol() - 1);
							while(getGrid().isValid(locChecker)) {
								locChecker = new Location(getLocation().getRow() + 1, getLocation().getCol() - 1);
								freeSpaces++;
							}
							spacesOpen[7] = freeSpaces;
							freeSpaces = 0;
							direction += 45;
							break;							
							
			}
			allChecked = direction;
		}
		int mostSpaces = spacesOpen[0];
		int temp;
		for (int i = 1; i < 8; i++)
		{
			if(spacesOpen[i] > mostSpaces) {
				mostOpen = i * 45;
				mostSpaces = spacesOpen[i];
			}
			
		}
		return mostOpen;
	}
	
	@Override
	protected void setBattleBugDirection() {
		Location next = getLocation().getAdjacentLocation(openDirection());
		
	}

	@Override
	protected String getName() {
		return "Steele";
	}

}
